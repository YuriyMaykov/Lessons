//функция проверки на четность
func isEven (_ number: Int = 0) -> Bool {
    return number % 2 == 0
}
//функция проверки деления без остатка
func isDividedWithoutRemainder (_ number: Int = 0, _ divider: Int = 1) -> Bool {
    return number % divider == 0
}

var n: Int = 14
var div: Int = 3

print(isEven(n) ? String(n) + " - четное число" : String(n) + " - не четное число")
print(isDividedWithoutRemainder(n, div)
    ? "делится без остатка на " + String(div)
    : "НЕ делится без остатка на "  + String(div))

//возрастающий массив из 100 чисел
var incrArr: [Int] = []
for i in 1...100 {
    incrArr.append(i)
}
print("Длина массива - \(incrArr.count), начинается с \(String(incrArr.first ?? 0)), заканчивается - \(String(incrArr.last ?? 0))")

print("убираем четные и не кратные 3 числа")
incrArr.removeAll { isEven($0) || !isDividedWithoutRemainder($0,3)}
print("Длина массива - \(incrArr.count), начинается с \(incrArr[0]), заканчивается - \(incrArr[incrArr.count > 0 ? incrArr.count - 1 : 0])")
print("incrArr = \(incrArr)")

//фунция возвращает массив чисел Фибоначчи длиной = nCount
func fibonachi (_ nBegin: Float80 = 1, _ nCount: Int = 2) -> Array<Float80> {
    var arr: [Float80] = [nBegin]
    for _ in 1...(nCount < 2 ? 2 : nCount) {
        arr.append(
            arr.count == 1 ? arr[0] : arr[arr.count - 2] + arr[arr.count - 1]
        )
    }
    return arr
}

var fibonachiArr  = fibonachi(Float80(0.0001), Int(100))
print("fibonachiArr = \(fibonachiArr)")

print("//Заполняем массив из 100 элементов различными простыми числами")
print("//вычисляем простые числа в массиве")
var S: [Int] = [0,0]  // 1 - не простое число
for _ in 2...99{
    S.append(1)  //заливаем массив еденицами
}
//print(S.count)
var k = 2
var l = k * k
while l <= S.count - 1 {
    if S[k] == 1 {  //если k не вычеркнуто
        while l <= S.count - 1 {
            S[l] = 0
            l += k
        }
    }
    k += 1
    l = k * k
}
//print(S)
var sieveOfEratosthenes: [Int] = []
for i in 1...S.count - 1 {
    if S[i] == 1 {
        sieveOfEratosthenes.append(i)
    }
}
print("решето Эратосфена - \(sieveOfEratosthenes)")
