//перечисления ================================================================
enum Poisition: String {
    case close = "Закрыты"
    case open = "Открыты"
}
enum OnOff: String {
    case On = "Включено"
    case Off = "Выключено"
}
//============================================================================
//Протоколы (интерфейсы) =====================================================
protocol IGarage {
    var garageId: Int { get }
    var garageWidth: Double { get }         //ширина
    var garageHeigth: Double { get }        //высота
    var garageLength: Double { get }        //длина(глубина)
    var gates: [IGate] { get set }          //ворота гаража
    
}

protocol IGate {                            //ворота
    var gateId: Int { get }                 //идентификатор ворот
    var gateWidth: Double { get }           //ширина
    var gateHeigth: Double { get }          //высота
    var gatePosition: Poisition { get set } //состояние (закрыты/открыты)
    //фунция управления воротами
    func gateControl ( command: Poisition, garageId: Int ) -> (Bool, String)
}

protocol ILighting {
    var lightingState: OnOff? { get set }    //освещение
    //функция управления освещением
    func lightingControl ( command:OnOff ) -> (Bool, String)
}

//============================================================================
//Классы =====================================================================
class Garage: IGarage, ILighting, CustomStringConvertible {
    init(garageId: Int,garageWidth: Double, garageHeigth: Double, garageLength: Double, gates: [IGate], lightingState: OnOff? ) {
        self.garageId = garageId
        self.garageWidth = garageWidth
        self.garageHeigth = garageHeigth
        self.garageLength = garageLength
        self.gates = gates
        self.lightingState = lightingState
    }

    var garageId: Int
    var garageWidth: Double
    var garageHeigth: Double
    var garageLength: Double
    var gates: [IGate]
    var lightingState: OnOff?
    var description: String {
        return("Гараж №\(garageId).")
    }

    func lightingControl (command: OnOff) -> (Bool, String) {
        var result = false
        var msg = ""
        let commandString = command == .On ? "включение" : "выключение"
        print("\(description) Получена команда на \(commandString) освещения. Текущее состояние: " + (lightingState?.rawValue ?? " не известно!"))

        if lightingState == nil {
            result = false
            msg = "Освещение отсутствует!"
            return (result, msg)
        }
        
        if command != lightingState {
            lightingState = command  //**команда в контроллер
            msg = "Освещение \(lightingState?.rawValue ?? " не известно!")"
            result = true   //success
        } else {
            msg = "Освещение было \(lightingState?.rawValue ?? " не известно!")"
            result = false   //not success
        }
        return (result, msg)
    }

    
}

//для примера реализации оставил класс ворот внешним. Освещенеие же реализовано внутри класса гаража
class Gate: IGate {
    init(gateId: Int, gateWidth: Double, gateHeigth: Double, gatePosition: Poisition) {
        self.gateId = gateId
        self.gateWidth = gateWidth
        self.gateHeigth = gateHeigth
        self.gatePosition = gatePosition
    }

    var gateId: Int
    var gateWidth: Double
    var gateHeigth: Double
    var gatePosition: Poisition
    
    func gateControl(command: Poisition, garageId: Int) -> (Bool, String) {
        var result = false
        var msg = ""
        let commandString = command == Poisition.close ? "закрыть" : "открыть"
        print("Гараж №\(garageId). Ворота №\(gateId). Получена команда: \(commandString).")
        if gatePosition != command {
            gatePosition = command      //**команда в контроллер
            msg = "Ворота №\(gateId) \(gatePosition.rawValue)"
            result = true
        } else {
            msg = "Ворота №\(gateId) были \(gatePosition.rawValue)"
            result = false
        }
        return (result, msg)
    }
}

class OtherFunc {
    func PrintResult(res: (Bool, String)) {
        print("Выполнение команды: " + (res.0 == true ? "выполнено. " : "отказ. ") + "\(res.1).")
    }
}

//============================================================================
var commandRes: (Bool, String)
var fn: OtherFunc = OtherFunc()
var garage1: Garage = Garage(
    garageId: 1
    , garageWidth: 7
    , garageHeigth: 3
    , garageLength: 8
    , gates: [
          Gate(gateId: 1, gateWidth: 2.7, gateHeigth: 2.5, gatePosition: Poisition.close)
        , Gate(gateId: 2, gateWidth: 3, gateHeigth: 4, gatePosition: Poisition.close)
        ]
    , lightingState: .Off
    )

commandRes = garage1.gates[0].gateControl(command: .open, garageId: garage1.garageId)
fn.PrintResult(res: commandRes)

commandRes = garage1.gates[0].gateControl(command: .open, garageId: garage1.garageId)
fn.PrintResult(res: commandRes)

commandRes = garage1.lightingControl(command: .Off)
fn.PrintResult(res: commandRes)

//в перспективе
protocol Processing {
    var boxes:[IGate] { get set }
    
    func openGate(garageId: Int, gateId: Int) -> (res: Bool, msg: String )
    func closeGate(garageId: Int, gateId: Int) -> (res: Bool, msg: String )
    func lightingOn(garageId: Int) -> (res: Bool, msg: String )
    func lightingOff(garageId: Int) -> (res: Bool, msg: String )
}
