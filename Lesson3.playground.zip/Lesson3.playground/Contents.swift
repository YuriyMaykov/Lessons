enum Poisition: String {
    case close = "Закрыты"
    case open = "Открыты"
}

enum OnOff: String {
    case On = "Включено"
    case Off = "Выключено"
}

struct Gate {   //ворота
    let id: Int //идентификатор ворот
    let width: Double   //ширина
    let heigth: Double  //высота
    var gatePosition: Poisition //состояние (закрыты/открыты)
    var airHeatCurtain: OnOff   //тепловая штора (включена/отключена)
}

struct Garage { //гараж
    let id: Int //идентификатор гаража
    let width: Double   //ширина
    let heigth: Double  //высота
    let length: Double  //длина(глубина)
    var gates = [Gate]()
    var lightingOnOff: OnOff    //освещение
}

var airTemperature: Double = -15.7  //температура воздуха снаружи
var garage = Garage(    //гараж как сущность (допустим получили данные из БД)
      id: 1
    , width: 7
    , heigth: 3
    , length: 8
    , gates: [
          Gate( id: 1, width: 2.7, heigth: 2.5, gatePosition: Poisition.close, airHeatCurtain: OnOff.Off)
        , Gate(id: 2, width: 3, heigth: 4, gatePosition: Poisition.close, airHeatCurtain: OnOff.Off)
    ]
    , lightingOnOff: OnOff.On
)

func LightingControl ( command:OnOff ) -> (Bool, String) { //функция управления освещением
    var result = false
    var msg = ""
    let commandString = command == .On ? "включение" : "выключение"
    print("Гараж №\(garage.id): получена команда на \(commandString) освещения. Текущее состояние: \(garage.lightingOnOff.rawValue)")

    switch command {
    case .On:  //если дана команда на включение
        if garage.lightingOnOff == OnOff.Off{ //проверяем текущее состояние освещения
            garage.lightingOnOff = command //если выключено - включаем
        }
        result = true   //ответочка
        msg = "Освещение: \(garage.lightingOnOff.rawValue)"
        
    case .Off:   //если дана команда на выключение
        if garage.lightingOnOff == OnOff.On{ //проверяем текущее состояние освещения
            garage.lightingOnOff = command //если включено - выключаем
        }
        result = true   //ответочка
        msg = "Освещение: \(garage.lightingOnOff.rawValue)"

    }
    return (result, msg)
}

func AirHeatControl ( gateIndex: Int, command: OnOff ) -> (Bool, String) {
    var result = false
    var msg = ""
    if (garage.gates.count < gateIndex+1) || gateIndex < 0  {
        result = false
        msg = "Ошибка данных."
        return (result, msg)
    }
    
    let commandString = command == .On ? "включение" : "выключение"
    print("Ворота №\(garage.gates[gateIndex].id): получена команда на \(commandString) тепловой шторы. Текущее состояние: \(garage.gates[gateIndex].airHeatCurtain.rawValue)")
    garage.gates[gateIndex].airHeatCurtain = command
    result = true
    msg = "Тепловая штора: \(garage.gates[gateIndex].airHeatCurtain.rawValue)"
    return (result, msg)
}

func GateControl ( gateId:Int, command:Poisition ) -> (Bool, String) {   //фунция управления воротами
    let commandString = command == Poisition.close ? "закрыть" : "открыть"
    print("Ворота №\(gateId). Получена команда: \(commandString).")
    var result = false
    var msg = ""
    if garage.gates.count == 0 {    //проверим не пустой ли массив
        result = false
        msg = "Ошибка команды: в гараже №\(garage.id) ворота отсутствуют !"
    } else {    //если не пустой, найдем строку с запрашиваемым номером
        var ind = -1
        for i in 0..<garage.gates.count{
            ind = (garage.gates[i].id == gateId) ? i : -1
            if ind >= 0 {   //строка найдена
                break
            }
        }
        if ind >= 0 {
            garage.gates[ind].gatePosition = command
            result = true
            msg = "Ворота: \(garage.gates[ind].gatePosition.rawValue)"
        } else {    //строка не найдена, вернем ошибку
            result = false
            msg = "Ошибка команды: ворота с №\(gateId) отсутствуют."
        }
    }
    return (result, msg)
}

var commandRes: (Bool, String)
func PrintResult(res: (Bool, String)){
    print(res.0 == true ? "Выполнение команды: успешно. \(res.1)." : "")
}
//-------------------------------------------------------------------//
//Процесс въезда автомобиля в гараж
commandRes = LightingControl( command: .On)
PrintResult(res: commandRes)

if airTemperature < 0 {
    commandRes = AirHeatControl(gateIndex: 0, command: .On)
    PrintResult(res: commandRes)
}

commandRes = GateControl(gateId: 1, command: .open)
PrintResult(res: commandRes)
if (commandRes.0 == false){
    commandRes = AirHeatControl(gateIndex: 0, command: .Off)
    PrintResult(res: commandRes)
    commandRes = LightingControl( command: .Off)
    PrintResult(res: commandRes)
}
//и автомобиль въезжает, закрываемся
commandRes = GateControl(gateId: 1, command: .close)
PrintResult(res: commandRes)
if (commandRes.0 == true){
    commandRes = AirHeatControl(gateIndex: 0, command: .Off)
    PrintResult(res: commandRes)
}




